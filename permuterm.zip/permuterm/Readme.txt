-----Team Members----

1. J S Sunil - S20160010033
2. K.Upendra - S20160010038
3. K. Sai Prasanna - S20160010047
4. N.Prudhvi - S20160010057

USAGE:

1) Setup:
	
	- Download the zip file of the project and install dependencies Lucene(7.4.0).
	- Add external lucene jar files common.jar, core.jar, queryparser.jar, demo.jar into the project in eclipse.
	- open LuceneWriteIndexFromFile.java and run the file to index the input files.

2) How to give Queries
	
	- Open LuceneReadIndexFromFile.java and run the file, you will be prompted with the console give the wildcard Query as input.
	- The matching file paths and corresponding scores will be displayed.
	
Example: s*n*e, An*a